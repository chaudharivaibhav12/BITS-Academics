To run the code, use the following commands on two different terminal and make sure the terminal is opened in the same folder where the files are present.

Server-
gcc server.c -o server
./server

Client-
gcc client.c -o client 
./client

After the programs start running, type the Messages in any of the terminals to send it and you can see the received message in the other terminal. 2-way communication is present. 