Important Points to be taken care of:


To run the code, use the following commands:

Client-
gcc client.c -o client -lssl -lcrypto


NOTE: Here the URL can be any of the URLS we want or the ones mentioned below:

My testcases were:
./client http://www.vinayaknaik.info/index.html
./client http://www.axmag.com/download/pdfurl-guide.pdf 
./client https://www.shreyasnisal.com/css/common.css

We can see that the code can download files of the type pdf, html, css etc. 
Also see the pdf file for more info.


